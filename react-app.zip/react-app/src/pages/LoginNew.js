import React, { Component } from 'react';
// import { withRouter } from 'react-router-dom';

class LoginNew extends Component {
  state = { email: '', password: '' };

  render() {
    return (
      <div>
        Login
      </div>
    );
  }
}
export default LoginNew;
