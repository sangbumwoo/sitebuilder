import React from 'react';

const Footer = () => (
  <div className="w3-indigo">
    <div className="w3-container" style={{ maxWidth: 960, margin: '0 auto' }}>
      Copyright SiteBuilder
    </div>
  </div>

);
export default Footer;
