class Config {
  constructor() {
    // this.apiUrl = 'http://localhost:1337/api/';
    this.apiUrl = 'http://ec2-13-125-208-224.ap-northeast-2.compute.amazonaws.com/api';
  }
}

export default (new Config());
