// function AppContextService($q, AppSettings, AuthService, CommonService) {
//     'ngInject';

//     this.context = {
//     };

// };


// app.factory('appContextService', function ($http, config) {

//     this.context = {
//     };


//     // return context;

// });

app.service('appContextService', function () {

    // this.appContextService = function (x) {
    //     return x.toString(16);
    // }

    this.context = {
    };


    // return context;

});